console.log("\n\n");
console.log("H   H EEEEE L     L      OOO       W   W  OOO  RRRR  L     DDDD  !!");
console.log("H   H E     L     L     O   O      W W W O   O R   R L     D   D !!");
console.log("HHHHH EEEEE L     L     O   O      W W W O   O RRRR  L     D   D !!");
console.log("H   H E     L     L     O   O  ,,   W W  O   O R   R L     D   D   ");
console.log("H   H EEEEE LLLLL LLLLL  OOO  ,,    W W   OOO  R   R LLLLL DDDD  !!");
console.log("\n");

// Taken from: https://en.wikipedia.org/wiki/ASCII_art

/* To run this simple hello world:
 * 1. You need to install node.js environment to your pc. See instructions
 *    from here: https://nodejs.org/en/
 * 2. Copy this file to a folder on your computer.
 * 3. Open terminal / command prompt
 * 4. Run a command: node hello.js
*/